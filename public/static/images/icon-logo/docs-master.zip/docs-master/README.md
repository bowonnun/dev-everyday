## Heavy Documentation Website


Requirements:

  * npm
  * grunt
  * sass

Generate the website to `./build` and watch for changes

```
$ npm install
$ grunt build
$ grunt serve
```
